package com.foodservice.RestaurantService.Controller;

import com.foodservice.RestaurantService.DTO.MenuResponseDTO;
import com.foodservice.RestaurantService.Model.MenuItem;
import com.foodservice.RestaurantService.Service.MenuService;
import com.foodservice.RestaurantService.Service.SpoonacularService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/menu")
public class MenuController {

    @Autowired
    private MenuService menuService;

    @Autowired
    private SpoonacularService spoonacularService;

    // ✅ Fetch menu items from the database or Spoonacular
    @GetMapping("/{restaurantId}")
    public ResponseEntity<List<MenuResponseDTO>> getMenuByRestaurantId(@PathVariable String restaurantId) {
        List<MenuResponseDTO> menu = menuService.getMenuByRestaurantId(restaurantId);
        return ResponseEntity.ok(menu);
    }

    // ✅ Fetch menu items from Spoonacular based on a keyword (e.g., "pizza")
    @GetMapping("/search")
    public ResponseEntity<List<MenuItem>> searchMenuItems(@RequestParam String query) {
        List<MenuItem> menuItems = spoonacularService.fetchMenuByQuery(query);
        return ResponseEntity.ok(menuItems);
    }

    @GetMapping("/cuisine")
    public ResponseEntity<List<MenuItem>> getMenuByCuisine(@RequestParam String cuisine) {
        List<MenuItem> menuItems = menuService.getMenuByCuisine(cuisine);
        return ResponseEntity.ok(menuItems);
    }
}
