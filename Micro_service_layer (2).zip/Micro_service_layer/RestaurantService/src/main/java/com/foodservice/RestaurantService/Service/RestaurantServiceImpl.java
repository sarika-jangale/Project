package com.foodservice.RestaurantService.Service;

import com.foodservice.RestaurantService.DTO.MenuResponseDTO;
import com.foodservice.RestaurantService.DTO.RestaurantResponseDTO;
import com.foodservice.RestaurantService.Model.MenuItem;
import com.foodservice.RestaurantService.Repository.MenuItemRepository;
import com.foodservice.RestaurantService.Repository.RestaurantRepository;
import com.foodservice.RestaurantService.Model.Restaurant;
import com.foodservice.RestaurantService.Util.CuisineDetector;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class RestaurantServiceImpl {

    @Autowired
    private GooglePlacesClient googlePlacesClient;

    @Autowired
    private RestaurantRepository restaurantRepository;

    @Autowired
    private MenuItemRepository menuItemRepository;

    @Autowired
    private SpoonacularService spoonacularService;


    private static final String API_KEY = "AIzaSyD8F4ziQLJeQEs1hvwhqkaxyfWuJC2Ywtc";

    public List<RestaurantResponseDTO> getRestaurants(String query) {
        // Check MongoDB cache first
        List<Restaurant> cachedRestaurants = restaurantRepository.findByNameContaining(query);

        if (!cachedRestaurants.isEmpty()) {
            System.out.println("Returning cached results for query: " + query);
            return cachedRestaurants.stream()
                    .map(restaurant -> new RestaurantResponseDTO(
                            restaurant.getName(), restaurant.getAddress(),
                            restaurant.getRating()))
                    .collect(Collectors.toList());
        }

        // If not in cache, fetch from Google Places API
        System.out.println("Fetching data from Google Places API for: " + query);
        List<RestaurantResponseDTO> apiResponse = googlePlacesClient.searchRestaurants(query, API_KEY);

        if (apiResponse.isEmpty()) {
            System.out.println("Google Places API returned no results for query: " + query);
            return apiResponse; // Return empty response if API has no results
        }

        // Save fetched data in MongoDB for caching
        List<Restaurant> restaurantsToSave = apiResponse.stream()
                .map(dto -> new Restaurant(null, dto.getName(), dto.getAddress(),
                        dto.getRating(), System.currentTimeMillis()))
                .collect(Collectors.toList());

        restaurantRepository.saveAll(restaurantsToSave);

        // Verify if data is saved in MongoDB
        System.out.println("Saved Restaurants in MongoDB: " + restaurantRepository.findAll());

        return apiResponse;
    }
    public List<RestaurantResponseDTO> getAllRestaurants() {
        List<Restaurant> allRestaurants = restaurantRepository.findAll();

        return allRestaurants.stream()
                .map(restaurant -> new RestaurantResponseDTO(
                        restaurant.getName(),
                        restaurant.getAddress(),
                        restaurant.getRating()))
                .collect(Collectors.toList());
    }
    public List<MenuResponseDTO> getMenuByRestaurantId(String restaurantId) {
        System.out.println("Fetching menu for restaurant ID: " + restaurantId);

        List<MenuItem> menuItems = menuItemRepository.findByRestaurantId(restaurantId);

        if (menuItems.isEmpty()) {
            System.out.println("No menu items found in the database.");
        }

        return menuItems.stream()
                .map(item -> new MenuResponseDTO(item.getName(), item.getPrice(), item.getImageUrl()))
                .collect(Collectors.toList());
    }


    public List<MenuItem> getMenuForRestaurant(String restaurantName) {
        // 🔹 Step 1: Detect cuisine based on restaurant name
        String cuisine = CuisineDetector.detectCuisine(restaurantName);

        // 🔹 Step 2: Fetch menu from Spoonacular API based on cuisine
        return spoonacularService.fetchMenuByQuery(cuisine);
    }


}