package com.foodservice.RestaurantService.Service;

import com.foodservice.RestaurantService.DTO.RestaurantResponseDTO;

import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;
@Component
public class GooglePlacesClient {
    private static final String GOOGLE_PLACES_URL = "https://maps.googleapis.com/maps/api/place/textsearch/json?query=%s&key=%s";

    public List<RestaurantResponseDTO> searchRestaurants(String query, String apiKey) {
        RestTemplate restTemplate = new RestTemplate();
        String url = String.format(GOOGLE_PLACES_URL, query, apiKey);

        ResponseEntity<String> response = restTemplate.getForEntity(url, String.class);

        // Log the API request and response
//        System.out.println("Google API URL: " + url);
//        System.out.println("Google API Response: " + response.getBody());

        List<RestaurantResponseDTO> restaurants = new ArrayList<>();

        try {
            JSONObject jsonResponse = new JSONObject(response.getBody());
            JSONArray results = jsonResponse.getJSONArray("results");

            for (int i = 0; i < results.length(); i++) {
                JSONObject place = results.getJSONObject(i);

                String name = place.optString("name", "Unknown");
                String address = place.optString("formatted_address", "No Address");
                String rating = place.has("rating") ? String.valueOf(place.getDouble("rating")) : "N/A";

                List<String> cuisines = new ArrayList<>();
                if (place.has("types")) {
                    JSONArray typesArray = place.getJSONArray("types");
                    for (int j = 0; j < typesArray.length(); j++) {
                        cuisines.add(typesArray.getString(j));
                    }
                }

                String phone = place.optString("formatted_phone_number", "No Phone");

                restaurants.add(new RestaurantResponseDTO(name, address, rating));
            }

        } catch (Exception e) {
            System.out.println("Error parsing Google Places API response: " + e.getMessage());
        }

        return restaurants;
    }
}