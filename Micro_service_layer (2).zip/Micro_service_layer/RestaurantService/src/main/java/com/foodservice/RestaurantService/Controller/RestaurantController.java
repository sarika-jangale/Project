package com.foodservice.RestaurantService.Controller;


import com.foodservice.RestaurantService.DTO.RestaurantResponseDTO;
import com.foodservice.RestaurantService.Model.MenuItem;
import com.foodservice.RestaurantService.Service.RestaurantServiceImpl;
import com.foodservice.RestaurantService.Service.SpoonacularService;
import com.foodservice.RestaurantService.Util.CuisineDetector;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/restaurants")
public class RestaurantController {

    @Autowired
    private RestaurantServiceImpl restaurantService;

    @Autowired
    private SpoonacularService spoonacularService;

    @Autowired
    private CuisineDetector cuisineDetector;
    @GetMapping("/search")
    public List<RestaurantResponseDTO> searchRestaurant(@RequestParam("restaurantName") String restaurantName) {
        if (restaurantName == null || restaurantName.isEmpty()) {
            throw new IllegalArgumentException("Restaurant name cannot be empty");
        }

        // Correct method call with proper parameter
        List<RestaurantResponseDTO> restaurant = restaurantService.getRestaurants(restaurantName);

        if (restaurant == null) {
            throw new RuntimeException("Restaurant not found: " + restaurantName);
        }

        return restaurant;
    }
    @GetMapping
    public ResponseEntity<List<RestaurantResponseDTO>> getAllRestaurants() {
        List<RestaurantResponseDTO> restaurants = restaurantService.getAllRestaurants();
        return ResponseEntity.ok(restaurants);
    }
    @GetMapping("/{restaurantName}/menu")
    public List<MenuItem> getMenuForRestaurant(@PathVariable String restaurantName) {
        String cuisine = cuisineDetector.detectCuisine(restaurantName); // Map cuisine
        return spoonacularService.fetchMenuByQuery(cuisine);
    }
    @GetMapping("/validate-menu-item")
    public ResponseEntity<Boolean> validateMenuItem(
            @RequestParam("restaurantName") String restaurantName,
            @RequestParam("menuItem") String menuItem) {

        List<MenuItem> menu = getMenuForRestaurant(restaurantName);

        boolean isValid = menu.stream().anyMatch(item -> item.getName().equalsIgnoreCase(menuItem));

        return ResponseEntity.ok(isValid);
    }

}


