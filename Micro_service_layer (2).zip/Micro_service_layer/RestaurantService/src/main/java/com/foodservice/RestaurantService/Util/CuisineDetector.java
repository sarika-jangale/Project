package com.foodservice.RestaurantService.Util;

import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
public class CuisineDetector {

    private static final Map<String, String> CUISINE_MAP = new HashMap<>();

    static {
        // ✅ Manually map popular restaurants to cuisines
        CUISINE_MAP.put("Domino's", "Italian");
        CUISINE_MAP.put("McDonald's", "American");
        CUISINE_MAP.put("KFC", "American");
        CUISINE_MAP.put("Sangeetha", "Indian");
        CUISINE_MAP.put("Saravana Bhavan", "South Indian");
        CUISINE_MAP.put("Mainland China", "Chinese");
        CUISINE_MAP.put("Burger King", "American");
        CUISINE_MAP.put("Subway", "Healthy");
        CUISINE_MAP.put("Taco Bell", "Mexican");
        CUISINE_MAP.put("Punjab Grill", "Indian");
        CUISINE_MAP.put("Bikanervala", "Indian");
        CUISINE_MAP.put("pizza", "italian");
        CUISINE_MAP.put("pasta", "italian");
        CUISINE_MAP.put("sushi", "japanese");
        CUISINE_MAP.put("burger", "american");
        CUISINE_MAP.put("biryani", "indian");
        CUISINE_MAP.put("tacos", "mexican");
        CUISINE_MAP.put("subway", "healthy");
        CUISINE_MAP.put("sandwich","healthy");
        CUISINE_MAP.put("ice cream", "vanilla ice cream");
    }

    public static String detectCuisine(String restaurantName) {
        // Normalize restaurant name for case-insensitive matching
        for (Map.Entry<String, String> entry : CUISINE_MAP.entrySet()) {
            if (restaurantName.toLowerCase().contains(entry.getKey().toLowerCase())) {
                return entry.getValue();
            }
        }
        return "General"; // Default if not found
    }
}
