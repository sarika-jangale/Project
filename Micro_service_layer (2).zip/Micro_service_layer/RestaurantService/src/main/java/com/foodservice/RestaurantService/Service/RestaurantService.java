package com.foodservice.RestaurantService.Service;

import com.foodservice.RestaurantService.DTO.RestaurantResponseDTO;

import java.util.List;

public interface RestaurantService {

    // Fetch restaurant by ID (First check in DB, then call Yelp API if not found)
    RestaurantResponseDTO getRestaurantById(String id);

    // Search restaurants using keywords (Calls Yelp API)
    List<RestaurantResponseDTO> searchRestaurants(String query);
    boolean restaurantExists(String name, String address);
}


