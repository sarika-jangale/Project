package com.foodservice.OrderService.Controller;

import com.foodservice.OrderService.DTO.CartRequestDTO;
import com.foodservice.OrderService.DTO.CartResponseDTO;
import com.foodservice.OrderService.Service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/cart")
public class CartController {

    @Autowired
    private CartService cartService;

    @PostMapping("/add")
    public ResponseEntity<CartResponseDTO> addToCart(@RequestParam String userEmail, @RequestBody CartRequestDTO cartRequest) {
        return ResponseEntity.ok(cartService.addToCart(userEmail, cartRequest));
    }

    @DeleteMapping("/remove/{cartItemId}")
    public ResponseEntity<CartResponseDTO> removeFromCart(@RequestParam String userEmail, @PathVariable String cartItemId) {
        return ResponseEntity.ok(cartService.removeFromCart(userEmail, cartItemId));
    }

    @GetMapping
    public ResponseEntity<CartResponseDTO> getCart(@RequestParam String userEmail) {
        return ResponseEntity.ok(cartService.getCart(userEmail));
    }

    @PutMapping("/update-quantity/{cartItemId}")
    public ResponseEntity<CartResponseDTO> updateQuantity(@RequestParam String userEmail, @PathVariable String cartItemId, @RequestParam int quantity) {
        return ResponseEntity.ok(cartService.updateQuantity(userEmail, cartItemId, quantity));
    }
}