package com.foodservice.OrderService.Domain;

public class OrderItem {

    private String menuItem;
    private int quantity;
    private double price;

    public OrderItem() {}

    public OrderItem(String menuItem, int quantity, double price) {

        this.menuItem = menuItem;
        this.quantity = quantity;
        this.price = price;
    }

    // Getters and Setters
    public String getMenuItem() {
        return menuItem;
    }

    public void setMenuItem(String menuItem) {
        this.menuItem = menuItem;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
}