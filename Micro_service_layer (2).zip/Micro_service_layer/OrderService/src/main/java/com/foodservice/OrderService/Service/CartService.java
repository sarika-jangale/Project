package com.foodservice.OrderService.Service;

import com.foodservice.OrderService.DTO.CartRequestDTO;
import com.foodservice.OrderService.DTO.CartResponseDTO;

public interface CartService {
    CartResponseDTO addToCart(String userEmail, CartRequestDTO cartRequest);
    CartResponseDTO removeFromCart(String userEmail, String cartItemId);
    CartResponseDTO getCart(String userEmail);
    CartResponseDTO updateQuantity(String userEmail, String cartItemId, int quantity);
}