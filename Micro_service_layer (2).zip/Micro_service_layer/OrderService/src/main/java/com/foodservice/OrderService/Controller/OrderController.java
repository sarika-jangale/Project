package com.foodservice.OrderService.Controller;

import com.foodservice.OrderService.DTO.OrderResponseDTO;
import com.foodservice.OrderService.Service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @PostMapping("/place")
    public ResponseEntity<OrderResponseDTO> placeOrder(@RequestParam String userEmail, @RequestParam String paymentMethod) {
        return ResponseEntity.ok(orderService.placeOrder(userEmail, paymentMethod));
    }

    @GetMapping("/user")
    public ResponseEntity<List<OrderResponseDTO>> getUserOrders(@RequestParam String userEmail) {
        return ResponseEntity.ok(orderService.getUserOrders(userEmail));
    }

    @PutMapping("/cancel/{orderId}")
    public ResponseEntity<OrderResponseDTO> cancelOrder(@PathVariable String orderId) {
        return ResponseEntity.ok(orderService.cancelOrder(orderId));
    }
}