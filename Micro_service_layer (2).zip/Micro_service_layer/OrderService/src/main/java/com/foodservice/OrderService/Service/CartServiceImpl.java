package com.foodservice.OrderService.Service;

import com.foodservice.OrderService.DTO.CartRequestDTO;
import com.foodservice.OrderService.DTO.CartResponseDTO;
import com.foodservice.OrderService.DTO.OrderItemDTO;
import com.foodservice.OrderService.Domain.Cart;
import com.foodservice.OrderService.Domain.OrderItem;
import com.foodservice.OrderService.Repository.CartRepository;
import com.foodservice.OrderService.Client.RestaurantServiceClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.HttpStatus;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CartServiceImpl implements CartService {

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private RestaurantServiceClient restaurantServiceClient;
    @Override
    public CartResponseDTO addToCart(String userEmail, CartRequestDTO cartRequest) {
        List<OrderItemDTO> items = cartRequest.getItems();

        for (OrderItemDTO item : items) {
            boolean isValidItem = restaurantServiceClient.validateMenuItem(
                    cartRequest.getRestaurantName(),
                    item.getItemName()  // Validate one item at a time
            ).getBody();

            if (!isValidItem) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid menu item: " + item.getItemName());
            }
        }

        Optional<Cart> existingCart = cartRepository.findByUserEmail(userEmail);
        Cart cart = existingCart.orElse(new Cart(userEmail, List.of()));

        // Convert OrderItemDTO to OrderItem (Check field names in OrderItem class)
        List<OrderItem> orderItems = items.stream()
                .map(dto -> new OrderItem(dto.getItemName(),dto.getQuantity(), dto.getPrice()))
                .collect(Collectors.toList());

        cart.setItems(orderItems);
        cartRepository.save(cart);

        return new CartResponseDTO(userEmail, items);
    }
    @Override
    public CartResponseDTO removeFromCart(String userEmail, String cartItemId) {
        Cart cart = cartRepository.findByUserEmail(userEmail)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Cart not found"));

        List<OrderItem> updatedItems = cart.getItems().stream()
                .filter(item -> !item.getMenuItem().equals(cartItemId))
                .collect(Collectors.toList());

        if (updatedItems.isEmpty()) {
            cartRepository.deleteByUserEmail(userEmail);
        } else {
            cart.setItems(updatedItems);
            cartRepository.save(cart);
        }

        List<OrderItemDTO> responseItems = updatedItems.stream()
                .map(item -> new OrderItemDTO(item.getMenuItem(), item.getQuantity(), item.getPrice()))
                .collect(Collectors.toList());

        return new CartResponseDTO(userEmail, responseItems);
    }

    @Override
    public CartResponseDTO getCart(String userEmail) {
        Cart cart = cartRepository.findByUserEmail(userEmail)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Cart not found"));

        List<OrderItemDTO> responseItems = cart.getItems().stream()
                .map(item -> new OrderItemDTO(item.getMenuItem(), item.getQuantity(), item.getPrice()))
                .collect(Collectors.toList());

        return new CartResponseDTO(userEmail, responseItems);
    }

    @Override
    public CartResponseDTO updateQuantity(String userEmail, String cartItemId, int quantity) {
        Cart cart = cartRepository.findByUserEmail(userEmail)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Cart not found"));

        List<OrderItem> updatedItems = cart.getItems().stream()
                .peek(item -> {
                    if (item.getMenuItem().equals(cartItemId)) {
                        item.setQuantity(quantity);
                    }
                })
                .collect(Collectors.toList());

        cart.setItems(updatedItems);
        cartRepository.save(cart);

        List<OrderItemDTO> responseItems = updatedItems.stream()
                .map(item -> new OrderItemDTO(item.getMenuItem(), item.getQuantity(), item.getPrice()))
                .collect(Collectors.toList());

        return new CartResponseDTO(userEmail, responseItems);
    }
}