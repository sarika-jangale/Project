package com.foodservice.OrderService.Service;

import com.foodservice.OrderService.DTO.OrderItemDTO;
import com.foodservice.OrderService.DTO.OrderResponseDTO;
import com.foodservice.OrderService.Domain.Cart;
import com.foodservice.OrderService.Domain.Order;
import com.foodservice.OrderService.Repository.CartRepository;
import com.foodservice.OrderService.Repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.HttpStatus;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private CartRepository cartRepository;

    @Override
    public OrderResponseDTO placeOrder(String userEmail, String paymentMethod) {
        Cart cart = cartRepository.findByUserEmail(userEmail)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Cart is empty"));

        double totalAmount = cart.getItems().stream()
                .mapToDouble(item -> item.getQuantity() * item.getPrice())
                .sum();

        Order order = new Order(userEmail, cart.getItems(), totalAmount, "PENDING", paymentMethod);
        orderRepository.save(order);
        cartRepository.deleteByUserEmail(userEmail);

        return new OrderResponseDTO(
                order.getId(),
                userEmail,
                order.getItems().stream()
                        .map(item -> new OrderItemDTO(item.getMenuItem(), item.getQuantity(), item.getPrice()))
                        .collect(Collectors.toList()), // ✅ Convert List<OrderItem> to List<OrderItemDTO>
                order.getTotalAmount(),
                order.getStatus(),
                order.getPaymentMethod()

        );
    }

    @Override
    public List<OrderResponseDTO> getUserOrders(String userEmail) {
        List<Order> orders = orderRepository.findByUserEmail(userEmail);

        return orders.stream()
                .map(order -> new OrderResponseDTO(
                        order.getId(),
                        userEmail,
                        order.getItems().stream()  // Convert List<OrderItem> to List<OrderItemDTO>
                                .map(item -> new OrderItemDTO(item.getMenuItem(), item.getQuantity(), item.getPrice()))
                                .collect(Collectors.toList()),
                        order.getTotalAmount(),
                        order.getStatus(),
                        order.getPaymentMethod()
                ))
                .collect(Collectors.toList());  // ✅ Convert to List<OrderResponseDTO>
    }

    @Override
    public OrderResponseDTO cancelOrder(String orderId) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Order not found"));

        order.setStatus("CANCELLED");
        orderRepository.save(order);

        // ✅ Convert List<OrderItem> to List<OrderItemDTO>
        List<OrderItemDTO> orderItemDTOs = order.getItems().stream()
                .map(item -> new OrderItemDTO(
                        item.getMenuItem(), // Ensure correct field mapping
                        item.getQuantity(),
                        item.getPrice()
                ))
                .collect(Collectors.toList());

        return new OrderResponseDTO(
                order.getId(),
                order.getUserEmail(),
                orderItemDTOs, // ✅ Corrected to pass List<OrderItemDTO>
                order.getTotalAmount(),
                order.getStatus(),
                order.getPaymentMethod()
        );
    }
}