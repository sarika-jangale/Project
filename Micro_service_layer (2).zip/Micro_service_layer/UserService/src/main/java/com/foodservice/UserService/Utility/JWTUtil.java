package com.foodservice.UserService.Utility;

import com.foodservice.UserService.Domain.User;
import io.jsonwebtoken.*;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Service
public class JWTUtil implements SecurityTokenGenerator {

    private static final String SECRET_KEY = "SecretKey"; // Use same key across services

    @Override
    public String createToken(User user) {
        Map<String, Object> claims = new HashMap<>();
        claims.put("email", user.getUserEmail());
        return generateToken(claims, user.getUserEmail());
    }

    private String generateToken(Map<String, Object> claims, String subject) {
        return Jwts.builder()
                .setIssuer("Foodservice")
                .setClaims(claims)
                .setSubject(subject)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + 1000 * 60 * 60)) // 1 hour validity
                .signWith(SignatureAlgorithm.HS256, SECRET_KEY) // HS256 for symmetric key
                .compact();
    }
    @Override
    public String extractEmailFromToken(String token) {
        Claims claims = Jwts.parser()
                .setSigningKey(SECRET_KEY)
                .parseClaimsJws(token.replace("Bearer ", "")) // Remove "Bearer " prefix
                .getBody();
        return claims.get("email", String.class);
    }
    public boolean validateToken(String token) {
        try {
            Jwts.parser().setSigningKey(SECRET_KEY).parseClaimsJws(token.replace("Bearer ", ""));
            return true; // Token is valid
        } catch (ExpiredJwtException e) {
            System.out.println("Token expired");
        } catch (UnsupportedJwtException e) {
            System.out.println("Unsupported token");
        } catch (MalformedJwtException e) {
            System.out.println("Malformed token");
        } catch (IllegalArgumentException e) {
            System.out.println("Illegal argument token");
        }
        return false; // Token is invalid
    }
}
