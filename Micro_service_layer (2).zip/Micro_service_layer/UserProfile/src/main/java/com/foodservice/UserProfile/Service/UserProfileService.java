package com.foodservice.UserProfile.Service;

import com.foodservice.UserProfile.Domain.UserProfile;

public interface UserProfileService {
    public UserProfile saveUserProfile(UserProfile userProfile);
}
