package com.foodservice.UserProfile.Repository;


import com.foodservice.UserProfile.Domain.UserProfile;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface UserProfileRepository extends MongoRepository<UserProfile, String> {
}